# NAIC

- Website: https://www.naicpe.com
- Industry: Private Equity Association
- Key contacts: [[carmen-mcghee]], [[jaye-washington]], [[marissa-mahoney]]
- Website: https://www.naicpe.com
- Industry: Professional Association / Private Equity Network
- Key contacts: [[carmen-mcghee]], [[jaye-washington]], [[marissa-mahoney]]

## Notes
National Association of Investment Companies - Premier network of diverse-owned private equity firms and professionals. Offers fellowship programs and industry connections.

## Opportunities
- 10-month compensated fellowship during school year (2nd years)
- NAIC-Akin Bootcamp
- Access to member firms including Blackstone Strategic Partners, Siris Capital, Sycamore Partners
- Warm introductions to network members
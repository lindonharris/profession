# New Catalyst

- Website: https://www.newcatalystsp.com
- Industry: Private Equity - Emerging Managers
- Key contacts: [[alice-wang]]

## Notes
Focus on value creation and differentiation. Provides fractionalized operating partners for emerging managers including IR/IR readiness and talent procurement.

## Opportunities
- Value creation focus
- Operating partner model
- Emerging manager ecosystem
# Firm Prospect List

---
created: 2024-01-10
updated: 2025-06-18
---

**

**

Firms that sound interesting:
-
Blue Owl

-
Hunter Point

-
Goldman Sachs Petershill
# L Catterton

- Website: https://www.lcatterton.com
- Industry: Consumer
- Key contacts: [[melvin-pina]]
- Website: https://www.lcatterton.com
- Industry: Private Equity - Consumer & Retail
- Key contacts: [[melvin-pina]]

## Notes
Largest consumer-focused private equity firm globally. Partnership with LVMH and Groupe Arnault. Focus on Consumer & Business Services, Buyout & Growth investments.

## Opportunities
- Consumer sector expertise
- Highly competitive MBA recruiting process
- Strong Wharton alumni network
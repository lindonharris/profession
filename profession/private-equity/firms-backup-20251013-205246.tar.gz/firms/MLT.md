# MLT

- Website: https://www.mlt.org
- Industry: Non-profit/Leadership Development
- Key contacts: [[olga-artman]], [[kevin-omar-williams]]
- Website: https://www.mlt.org
- Industry: Talent Development / Professional Network
- Key contacts: [[olga-artman]], [[kevin-omar-williams]]

## Notes
Management Leadership for Tomorrow - Leading organization for developing diverse talent in business. Runs MLT XP program focused on private equity recruiting and career development.

## Opportunities
- MLT XP program participation
- PE Accelerator for associate pipeline
- AltFinance program partnerships
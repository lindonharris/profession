# Coatue

---
created: 2025-08-20
updated: 2025-08-20
---

- Website: https://www.coatue.com
- Industry: [ ]
- Key contacts: [ ]

## Target Strategies
1. **Primary**: Structured Investments - Why (IMOW): [ ]
2. **Secondary**: [ ]
3. **Other**: [ ]

## Notes


## Opportunities
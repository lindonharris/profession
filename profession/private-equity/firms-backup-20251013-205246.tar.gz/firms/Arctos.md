# Arctos

- Website: https://www.arctospartners.com
- Industry: Sports & Entertainment
- Key contacts: [[jordan-solomon]], [[ian-charles]], [[joe-corcoran]], [[alastair-seaman]]
- Website: https://www.arctospartners.com
- Industry: Sports & Entertainment, Alternative Assets
- Key contacts: [[alastair-seaman]], [[ian-charles]], [[joe-corcoran]], [[jordan-solomon]]

## Notes
Leading investment platform focused on sports franchises, leagues, and related businesses. Also manages Keystone strategy for alternative asset opportunities.

## Opportunities
- Strong existing relationships with multiple partners
- Potential summer internship opportunities (even unpaid)
- GP stakes strategy alignment
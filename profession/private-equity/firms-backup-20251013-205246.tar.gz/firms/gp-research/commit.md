# GP Commit

---
created: 2024-01-08
updated: 2024-01-08
---

**

How much do I need? 10-20% of total fundraise
- 
when I start a GP, I don't want to be too diluted by capital commitment of other founding partners

- 
I need to have at least 5% ready

- 
For a $250M fundraise, that's $12.5M

- 
For a $500M fundraise, that's $25M 

- 
For a $1B fundraise, that's $50M

- 
In some ways, this capital amount that I have built will be a limiting factor to the total amount that we target

**

Bootstrap
- 
Personal earnings via venture portfolio

- 
ProvenPath

- 
Car Wash?

**

External Capital
- 
Stable AM
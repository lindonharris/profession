# Arctos Relationships (other)

---
created: 2023-11-01
updated: 2024-08-07
---

**

**Chad Hutchinson - 11/30/23**
- 
Thinks the Inspiration biz is interesting and great experience for me - happy for me

- 
Was concerned that Arctos did something wrong

- 
Will come out of MBA VP/director-level potentially

- 
Stay in touch throughout the new year

**

**Jacob Harrison - 12/6/23**
- 
Almost no sports deals anymore

- 
Waiting on NFL - coin flip in March

- 
Some owners very strongly opposed 

- 
Arctos investment team is overstaffed

- 
Leadership is noticeably slow to promote

- 
Wants to stay at Arctos long-term but anxious about feedback cycle

**

**Melissa Kelly - 3/16/24**
- 
Feels like she is being "pushed out"

- 
Unfair promotion philosophy

- 
Keystone strategy is a challenging fundraise (sub-$1B vs. $4B target)

- 
Sports is wagered nearly entirely on the NFL unlock

- 
Fell into a money-hungry / materialistic culture

**

**Nick Skornia - 4/1/24**
- 
Serious gripes with Arctos experience - not a "family"

- 
Struggled to find something given unique niche

******
# 26 North

- Website: https://www.26northpartners.com
- Industry: [ ]
- Key contacts: [[priyanka-fouda]]
- Website: https://www.26north.com
- Industry: Alternative Asset Management
- Key contacts: [[priyanka-fouda]]

## Notes
Multi-strategy alternative asset manager with business lines similar to Apollo Strategic: Flagship PE, Direct lending, Insurance. Founded by Josh Harris after leaving Apollo. Differentiated McKinsey relationship with McKinsey as LP.

## Opportunities
- Upper MM buyout and special situations
- Strong technical focus in recruiting
- 6-month recruiting timeline
- Target fund size: $4-5 billion
- Hiring at mid-level and MBA+5 level
- Ian Charles connection to 26N ecosystem
- Contact: Nwokiae, TK (VP Amsec) for prep materials